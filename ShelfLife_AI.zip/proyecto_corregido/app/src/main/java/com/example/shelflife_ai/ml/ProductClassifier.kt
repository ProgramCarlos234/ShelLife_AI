package com.example.shelflife_ai.ml

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.exp

data class Prediction(
    val rawLabel: String,
    val confidence: Float
) {
    val info: LabelInfo get() = ProductLabels.infoFor(rawLabel)
}

/** Resultado final: o hay un producto válido, o un motivo para rechazar. */
data class Decision(val prediction: Prediction?, val motivo: String)

/**
 * Clasificador YOLOv8-cls (best.tflite).
 *  - Entrada : float32 [1, 3, 224, 224] (NCHW, RGB, 0..1)
 *  - Salida  : float32 [1, N]           (una probabilidad por línea de labels.txt)
 */
class ProductClassifier(context: Context) : AutoCloseable {

    private val interpreter: Interpreter
    private val labels: List<String>
    private val inputSize = 224

    private val inputBuffer: ByteBuffer =
        ByteBuffer.allocateDirect(4 * 3 * inputSize * inputSize).order(ByteOrder.nativeOrder())
    private val pixels = IntArray(inputSize * inputSize)

    init {
        val app = context.applicationContext
        labels = app.assets.open(LABELS_FILE).bufferedReader().useLines { lines ->
            lines.map { it.trim() }.filter { it.isNotEmpty() }.toList()
        }

        val fd = app.assets.openFd(MODEL_FILE)
        val mapped = FileInputStream(fd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        interpreter = Interpreter(mapped, Interpreter.Options().apply { setNumThreads(4) })

        val outClasses = interpreter.getOutputTensor(0).shape().last()
        require(outClasses == labels.size) {
            "El modelo tiene $outClasses clases pero labels.txt tiene ${labels.size} líneas"
        }
    }

    /** Devuelve las [topK] mejores predicciones, de mayor a menor confianza. */
    @Synchronized
    fun classify(bitmap: Bitmap, topK: Int = 3): List<Prediction> {
        fillInput(bitmap)

        val output = Array(1) { FloatArray(labels.size) }
        interpreter.run(inputBuffer, output)

        val scores = normalize(output[0])
        return scores.indices
            .sortedByDescending { scores[it] }
            .take(topK)
            .map { Prediction(labels[it], scores[it]) }
    }

    /**
     * Aplica las reglas de aceptación. Un producto solo se acepta si:
     *  1. la clase principal no es "no_alimento",
     *  2. la confianza alcanza [MIN_CONFIDENCE],
     *  3. supera a la segunda opción por al menos [MIN_MARGIN].
     * Recibe las predicciones de [classify] con topK >= 2.
     */
    fun decide(predictions: List<Prediction>): Decision {
        val best = predictions.firstOrNull()
            ?: return Decision(null, "Objeto no reconocido")
        if (best.rawLabel == REJECT_LABEL)
            return Decision(null, "No es un alimento")
        if (best.confidence < MIN_CONFIDENCE)
            return Decision(null, "Objeto no reconocido con certeza")
        val segundo = predictions.getOrNull(1)?.confidence ?: 0f
        if (best.confidence - segundo < MIN_MARGIN)
            return Decision(null, "Resultado ambiguo")
        return Decision(best, "ok")
    }

    /** Recorte cuadrado central + resize a 224x224 (igual que Ultralytics) y paso a NCHW. */
    private fun fillInput(src: Bitmap) {
        val side = minOf(src.width, src.height)
        val x = (src.width - side) / 2
        val y = (src.height - side) / 2
        val cropped = Bitmap.createBitmap(src, x, y, side, side)
        val scaled = Bitmap.createScaledBitmap(cropped, inputSize, inputSize, true)
        scaled.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
        if (scaled !== cropped) scaled.recycle()
        if (cropped !== src) cropped.recycle()

        inputBuffer.rewind()
        val plane = inputSize * inputSize
        for (c in 0 until 3) {
            val shift = when (c) { 0 -> 16; 1 -> 8; else -> 0 }
            for (i in 0 until plane) {
                inputBuffer.putFloat(((pixels[i] shr shift) and 0xFF) / 255f)
            }
        }
        inputBuffer.rewind()
    }

    /** La exportación de Ultralytics normalmente ya incluye softmax; si no, lo aplicamos. */
    private fun normalize(raw: FloatArray): FloatArray {
        val sum = raw.sum()
        val alreadyProbabilities = raw.all { it in 0f..1f } && sum in 0.98f..1.02f
        if (alreadyProbabilities) return raw
        val max = raw.max()
        val exps = FloatArray(raw.size) { exp(raw[it] - max) }
        val total = exps.sum()
        return FloatArray(raw.size) { exps[it] / total }
    }

    override fun close() = interpreter.close()

    companion object {
        private const val MODEL_FILE = "best.tflite"
        private const val LABELS_FILE = "labels.txt"
        const val REJECT_LABEL = "no_alimento"
        const val MIN_CONFIDENCE = 0.75f
        const val MIN_MARGIN = 0.20f
    }
}

/**
 * Instancia única compartida por todas las pantallas. Evita cargar el modelo
 * varias veces y no lo cierra al salir de una pantalla.
 */
object ClassifierHolder {
    @Volatile private var instance: ProductClassifier? = null

    fun get(context: Context): ProductClassifier? {
        instance?.let { return it }
        synchronized(this) {
            if (instance == null) {
                instance = runCatching { ProductClassifier(context.applicationContext) }.getOrNull()
            }
            return instance
        }
    }
}
