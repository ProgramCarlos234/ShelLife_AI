package com.example.shelflife_ai.ml

/**
 * Traduce las clases del modelo (labels.txt, en inglés) a un nombre en español
 * y a una de las categorías que ya usa AddProductScreen.
 */
data class LabelInfo(val displayName: String, val category: String)

object ProductLabels {
    private const val FRUTAS = "Frutas"
    private const val VERDURAS = "Verduras"
    private const val CARNES = "Carnes y Embutidos"

    private val map: Map<String, LabelInfo> = mapOf(
        "apple" to LabelInfo("Manzana", FRUTAS),
        "banana" to LabelInfo("Plátano", FRUTAS),
        "beetroot" to LabelInfo("Betarraga", VERDURAS),
        "bell_pepper" to LabelInfo("Pimiento", VERDURAS),
        "cabbage" to LabelInfo("Repollo", VERDURAS),
        "capsicum" to LabelInfo("Pimiento", VERDURAS),
        "carne_valid" to LabelInfo("Carne", CARNES),
        "carrot" to LabelInfo("Zanahoria", VERDURAS),
        "cauliflower" to LabelInfo("Coliflor", VERDURAS),
        "chilli_pepper" to LabelInfo("Ají", VERDURAS),
        "corn" to LabelInfo("Choclo", VERDURAS),
        "cucumber" to LabelInfo("Pepino", VERDURAS),
        "eggplant" to LabelInfo("Berenjena", VERDURAS),
        "garlic" to LabelInfo("Ajo", VERDURAS),
        "ginger" to LabelInfo("Jengibre", VERDURAS),
        "grapes" to LabelInfo("Uvas", FRUTAS),
        "jalepeno" to LabelInfo("Jalapeño", VERDURAS),
        "kiwi" to LabelInfo("Kiwi", FRUTAS),
        "lemon" to LabelInfo("Limón", FRUTAS),
        "lettuce" to LabelInfo("Lechuga", VERDURAS),
        "mango" to LabelInfo("Mango", FRUTAS),
        "onion" to LabelInfo("Cebolla", VERDURAS),
        "orange" to LabelInfo("Naranja", FRUTAS),
        "paprika" to LabelInfo("Pimentón", VERDURAS),
        "pear" to LabelInfo("Pera", FRUTAS),
        "peas" to LabelInfo("Arvejas", VERDURAS),
        "pineapple" to LabelInfo("Piña", FRUTAS),
        "pomegranate" to LabelInfo("Granada", FRUTAS),
        "potato" to LabelInfo("Papa", VERDURAS),
        "raddish" to LabelInfo("Rabanito", VERDURAS),
        "soy_beans" to LabelInfo("Soya", VERDURAS),
        "spinach" to LabelInfo("Espinaca", VERDURAS),
        "sweetcorn" to LabelInfo("Choclo dulce", VERDURAS),
        "sweetpotato" to LabelInfo("Camote", VERDURAS),
        "tomato" to LabelInfo("Tomate", VERDURAS),
        "turnip" to LabelInfo("Nabo", VERDURAS),
        "watermelon" to LabelInfo("Sandía", FRUTAS),
        "no_alimento" to LabelInfo("No alimento", "Otros")
    )

    fun infoFor(rawLabel: String): LabelInfo =
        map[rawLabel] ?: LabelInfo(rawLabel.replace('_', ' ').replaceFirstChar { it.uppercase() }, "Otros")
}
