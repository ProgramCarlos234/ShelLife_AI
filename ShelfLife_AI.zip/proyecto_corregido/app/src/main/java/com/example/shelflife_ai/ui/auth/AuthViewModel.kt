package com.example.shelflife_ai.ui.auth

import android.app.Activity
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    data class Success(val message: String? = null) : AuthState()
    data class Error(val message: String) : AuthState()
    data class OtpSent(val verificationId: String) : AuthState()
}

class AuthViewModel : ViewModel() {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private var resendingToken: PhoneAuthProvider.ForceResendingToken? = null

    fun resetState() {
        _authState.value = AuthState.Idle
    }

    fun registerWithEmail(
        username: String,
        email: String,
        phone: String,
        displayName: String,
        password: String,
        confirmPassword: String,
        termsAccepted: Boolean
    ) {
        val cleanUsername = username.trim().lowercase()
        val cleanEmail = email.trim()
        val cleanPassword = password

        if (cleanUsername.isBlank()) {
            _authState.value = AuthState.Error("El nombre de usuario es obligatorio.")
            return
        }
        if (cleanUsername.contains(" ")) {
            _authState.value = AuthState.Error("El nombre de usuario no puede contener espacios.")
            return
        }
        if (!termsAccepted) {
            _authState.value = AuthState.Error("Debes aceptar los términos y condiciones.")
            return
        }
        if (cleanEmail.isBlank() || cleanPassword.isBlank()) {
            _authState.value = AuthState.Error("Por favor completa el correo y la contraseña.")
            return
        }
        if (cleanPassword != confirmPassword) {
            _authState.value = AuthState.Error("Las contraseñas no coinciden.")
            return
        }
        if (cleanPassword.length < 8) {
            _authState.value = AuthState.Error("La contraseña debe tener al menos 8 caracteres.")
            return
        }

        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                // 1. Validar nombre de usuario único en Firestore
                try {
                    val existingUsers = firestore.collection("users")
                        .whereEqualTo("usernameLower", cleanUsername)
                        .get()
                        .await()

                    if (!existingUsers.isEmpty) {
                        _authState.value = AuthState.Error("Este nombre de usuario ya está en uso.")
                        return@launch
                    }
                } catch (e: FirebaseFirestoreException) {
                    if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        Log.w("AuthError", "Sin permisos para consultar nombres de usuario en Firestore antes de autenticarse.", e)
                        // Continuamos para crear la cuenta en Auth
                    } else {
                        throw e
                    }
                }

                // 2. Crear cuenta en Firebase Auth
                val result = auth.createUserWithEmailAndPassword(cleanEmail, cleanPassword).await()
                val user = result.user

                if (user != null) {
                    try {
                        user.sendEmailVerification()
                    } catch (e: Exception) {
                        Log.w("AuthError", "No se pudo enviar el correo de verificación", e)
                    }

                    val defaultAvatar = "https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}"

                    val newUserMap = mapOf(
                        "uid" to user.uid,
                        "username" to username.trim(),
                        "usernameLower" to cleanUsername,
                        "email" to cleanEmail,
                        "phone" to phone.trim(),
                        "displayName" to displayName.trim().ifBlank { username.trim() },
                        "photoUrl" to defaultAvatar,
                        "createdAt" to System.currentTimeMillis()
                    )

                    firestore.collection("users").document(user.uid).set(newUserMap, SetOptions.merge()).await()
                    _authState.value = AuthState.Success("Registro exitoso. Se envió un correo de verificación.")
                } else {
                    _authState.value = AuthState.Error("Error al registrar el usuario.")
                }
            } catch (e: FirebaseAuthUserCollisionException) {
                Log.e("AuthError", "Correo ya registrado. ErrorCode: ${e.errorCode}", e)
                _authState.value = AuthState.Error("Ya existe una cuenta registrada con este correo electrónico.")
            } catch (e: FirebaseAuthWeakPasswordException) {
                Log.e("AuthError", "Contraseña débil. ErrorCode: ${e.errorCode}", e)
                _authState.value = AuthState.Error("La contraseña es muy débil. Elige una más segura.")
            } catch (e: FirebaseNetworkException) {
                Log.e("AuthError", "Error de red en registro.", e)
                _authState.value = AuthState.Error("Error de conexión. Verifica tu acceso a internet.")
            } catch (e: FirebaseAuthException) {
                Log.e("AuthError", "Error de Firebase Auth en registro. ErrorCode: ${e.errorCode}", e)
                _authState.value = AuthState.Error("Error de autenticación: ${e.localizedMessage}")
            } catch (e: FirebaseFirestoreException) {
                Log.e("AuthError", "Error de Firestore en registro. Code: ${e.code}", e)
                if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                    _authState.value = AuthState.Error("Permisos insuficientes en la base de datos para completar el registro.")
                } else {
                    _authState.value = AuthState.Error("Error en la base de datos: ${e.localizedMessage}")
                }
            } catch (e: Exception) {
                Log.e("AuthError", "Error inesperado en registro", e)
                _authState.value = AuthState.Error(e.localizedMessage ?: "Error en el registro.")
            }
        }
    }

    fun loginWithEmail(emailOrUsername: String, password: String) {
        val cleanInput = emailOrUsername.trim()
        val cleanPassword = password

        if (cleanInput.isBlank() || cleanPassword.isBlank()) {
            _authState.value = AuthState.Error("Por favor ingresa tu correo/usuario y contraseña.")
            return
        }

        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                // Determinar si el usuario ingresó un correo o un nombre de usuario
                val targetEmail = if (cleanInput.contains("@")) {
                    // Si contiene '@', es un correo válido: NO tocar Firestore antes de autenticarse
                    cleanInput
                } else {
                    // Si es un nombre de usuario, intentar buscar el correo asociado en Firestore
                    try {
                        val userQuery = firestore.collection("users")
                            .whereEqualTo("usernameLower", cleanInput.lowercase())
                            .get()
                            .await()

                        if (userQuery.isEmpty) {
                            _authState.value = AuthState.Error("No se encontró ningún usuario con el nombre '$cleanInput'. Intenta ingresar tu correo electrónico.")
                            return@launch
                        }

                        userQuery.documents.firstNotNullOfOrNull { it.getString("email") } ?: run {
                            _authState.value = AuthState.Error("No se pudo obtener el correo asociado a este usuario.")
                            return@launch
                        }
                    } catch (e: FirebaseFirestoreException) {
                        if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                            Log.e("AuthError", "Acceso denegado al buscar nombre de usuario sin autenticar.", e)
                            _authState.value = AuthState.Error("No se pudo verificar el nombre de usuario. Por favor inicia sesión usando tu correo electrónico.")
                            return@launch
                        } else {
                            throw e
                        }
                    }
                }

                // Autenticar directamente en Firebase Auth
                val result = auth.signInWithEmailAndPassword(targetEmail, cleanPassword).await()
                val user = result.user

                if (user != null) {
                    _authState.value = AuthState.Success("Inicio de sesión exitoso.")
                } else {
                    _authState.value = AuthState.Error("Error al iniciar sesión.")
                }
            } catch (e: FirebaseAuthInvalidUserException) {
                Log.e("AuthError", "Usuario no existe o deshabilitado. ErrorCode: ${e.errorCode}", e)
                _authState.value = AuthState.Error("No existe una cuenta registrada con este correo/usuario o ha sido deshabilitada.")
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                Log.e("AuthError", "Credenciales inválidas. ErrorCode: ${e.errorCode}", e)
                _authState.value = AuthState.Error("La contraseña es incorrecta o el formato de las credenciales no es válido.")
            } catch (e: FirebaseNetworkException) {
                Log.e("AuthError", "Error de red en inicio de sesión.", e)
                _authState.value = AuthState.Error("Error de conexión a internet. Por favor verifica tu red e intenta nuevamente.")
            } catch (e: FirebaseAuthException) {
                Log.e("AuthError", "Error de Firebase Auth en login. ErrorCode: ${e.errorCode}", e)
                _authState.value = AuthState.Error("Error de autenticación: ${e.localizedMessage}")
            } catch (e: FirebaseFirestoreException) {
                Log.e("AuthError", "Error de Firestore durante login. Code: ${e.code}", e)
                if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                    _authState.value = AuthState.Error("Permisos insuficientes en la base de datos. Intenta iniciar sesión con tu correo electrónico.")
                } else {
                    _authState.value = AuthState.Error("Error en la base de datos: ${e.localizedMessage}")
                }
            } catch (e: Exception) {
                Log.e("AuthError", "Error inesperado en inicio de sesión", e)
                _authState.value = AuthState.Error(e.localizedMessage ?: "Error de autenticación.")
            }
        }
    }

    fun signInWithGoogleToken(idToken: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                val result = auth.signInWithCredential(credential).await()
                val user = result.user

                if (user != null) {
                    val defaultUsername = user.email?.substringBefore("@") ?: "user_${user.uid.take(5)}"
                    saveUserIfNotExists(
                        uid = user.uid,
                        username = defaultUsername,
                        email = user.email ?: "",
                        phone = user.phoneNumber ?: "",
                        displayName = user.displayName ?: defaultUsername,
                        photoUrl = user.photoUrl?.toString() ?: "https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}"
                    )
                    _authState.value = AuthState.Success("Inicio de sesión con Google exitoso.")
                }
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.localizedMessage ?: "Error al autenticar con Google.")
            }
        }
    }

    fun sendSmsOtp(phoneNumber: String, activity: Activity) {
        if (phoneNumber.isBlank()) {
            _authState.value = AuthState.Error("Por favor ingresa un número de teléfono válido (+51...).")
            return
        }

        _authState.value = AuthState.Loading

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    signInWithPhoneCredential(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    _authState.value = AuthState.Error(e.localizedMessage ?: "Error al enviar código SMS.")
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    resendingToken = token
                    _authState.value = AuthState.OtpSent(verificationId)
                }
            })
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifySmsOtp(verificationId: String, otpCode: String) {
        if (otpCode.isBlank()) {
            _authState.value = AuthState.Error("Ingresa el código OTP de 6 dígitos.")
            return
        }

        val credential = PhoneAuthProvider.getCredential(verificationId, otpCode)
        signInWithPhoneCredential(credential)
    }

    private fun signInWithPhoneCredential(credential: PhoneAuthCredential) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val result = auth.signInWithCredential(credential).await()
                val user = result.user

                if (user != null) {
                    val defaultUsername = "user_${user.uid.take(6)}"
                    saveUserIfNotExists(
                        uid = user.uid,
                        username = defaultUsername,
                        email = user.email ?: "",
                        phone = user.phoneNumber ?: "",
                        displayName = "Usuario SMS",
                        photoUrl = "https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}"
                    )
                    _authState.value = AuthState.Success("Autenticación por SMS exitosa.")
                }
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.localizedMessage ?: "Código OTP incorrecto o expirado.")
            }
        }
    }

    private suspend fun saveUserIfNotExists(
        uid: String,
        username: String,
        email: String,
        phone: String,
        displayName: String,
        photoUrl: String
    ) {
        val userDoc = firestore.collection("users").document(uid).get().await()
        if (!userDoc.exists()) {
            val newUserMap = mapOf(
                "uid" to uid,
                "username" to username,
                "usernameLower" to username.lowercase(),
                "email" to email,
                "phone" to phone,
                "displayName" to displayName,
                "photoUrl" to photoUrl,
                "createdAt" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).set(newUserMap, SetOptions.merge()).await()
        }
    }
}
