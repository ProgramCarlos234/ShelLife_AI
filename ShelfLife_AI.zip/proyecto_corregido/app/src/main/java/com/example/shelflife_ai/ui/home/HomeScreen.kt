package com.example.shelflife_ai.ui.home

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview as CameraPreview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import coil.decode.SvgDecoder
import coil.request.ImageRequest
import com.example.shelflife_ai.data.UserPreferences
import com.example.shelflife_ai.getCoilImageModel
import com.example.shelflife_ai.ml.Prediction
import com.example.shelflife_ai.ml.ClassifierHolder
import com.example.shelflife_ai.ml.ProductClassifier
import com.example.shelflife_ai.model.ProductModel
import com.example.shelflife_ai.model.UserModel
import com.example.shelflife_ai.ui.product.ProductViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.min

data class ProductColorTheme(
    val backgroundColor: Color,
    val borderColor: Color,
    val textColor: Color
)

fun getProductStatusColor(expirationDate: Long): ProductColorTheme {
    val nowMillis = System.currentTimeMillis()
    val daysLeft = ((expirationDate - nowMillis) / (1000 * 60 * 60 * 24)).toInt()

    return when {
        daysLeft < 15 -> ProductColorTheme(
            backgroundColor = Color(0xFFFFEBEE),
            borderColor = Color(0xFFE57373),
            textColor = Color(0xFFC62828)
        )
        daysLeft in 15..30 -> ProductColorTheme(
            backgroundColor = Color(0xFFFFF8E1),
            borderColor = Color(0xFFFFB74D),
            textColor = Color(0xFFEF6C00)
        )
        else -> ProductColorTheme(
            backgroundColor = Color(0xFFE8F5E9),
            borderColor = Color(0xFF81C784),
            textColor = Color(0xFF2E7D32)
        )
    }
}

fun getCategoryIcon(category: String): ImageVector {
    return when (category) {
        "Frutas", "Verduras" -> Icons.Default.Eco
        "Carnes y Embutidos" -> Icons.Default.Restaurant
        "Lácteos" -> Icons.Default.Icecream
        "Bebidas" -> Icons.Default.LocalBar
        "Abarrotes / Despensa" -> Icons.Default.ShoppingBag
        else -> Icons.Default.Fastfood
    }
}

fun getDefaultDaysAndTipForCategory(category: String): Pair<Int, String> {
    return when (category) {
        "Frutas" -> Pair(3, "Fruta cortada o pelada dura aprox. 3 días en refrigeración.")
        "Verduras" -> Pair(4, "Verdura cortada o cocida dura aprox. 4 días en refrigeración.")
        "Carnes y Embutidos" -> Pair(4, "Carnes molidas 1-2 días; sobras 3-4 días; fiambres 3-5 días.")
        "Lácteos" -> Pair(3, "Leche y yogur abiertos 3 días; queso duro y mantequilla hasta 3 semanas.")
        "Bebidas" -> Pair(7, "Jugos y refrescos 7-10 días; gaseosas abiertas 2-3 días.")
        "Abarrotes / Despensa" -> Pair(30, "Salsas de frasco y conservas 3-4 días; mermeladas y aderezos 1-3 meses.")
        else -> Pair(7, "Ingresa la duración sugerida según el producto.")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    productViewModel: ProductViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToAddProduct: () -> Unit,
    onSignOut: () -> Unit
) {
    val auth = FirebaseAuth.getInstance()
    val firestore = FirebaseFirestore.getInstance()
    val currentUser = auth.currentUser

    var currentTab by remember { mutableIntStateOf(0) } // 0: Inicio, 1: Recetas, 2: Escanear, 3: Frescos, 4: Impacto

    var userModel by remember { mutableStateOf<UserModel?>(null) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val userPreferences = remember { UserPreferences(context) }
    val isTutorialSeenState by userPreferences.isTutorialSeen.collectAsState(initial = false)
    var showTutorialManually by remember { mutableStateOf(false) }

    val shouldShowTutorial = showTutorialManually || !isTutorialSeenState
    var tutorialStep by remember { mutableStateOf(1) }

    val products by productViewModel.products.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedStorageFilter by remember { mutableStateOf("Todos") }

    var productToOpen by remember { mutableStateOf<ProductModel?>(null) }
    var openDaysInput by remember { mutableStateOf("3") }
    var currentTip by remember { mutableStateOf("") }

    var productToDelete by remember { mutableStateOf<ProductModel?>(null) }

    val dateFormatter = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    LaunchedEffect(Unit) {
        if (currentUser != null) {
            try {
                val doc = firestore.collection("users").document(currentUser.uid).get().await()
                val user = doc.toObject(UserModel::class.java)
                userModel = user ?: UserModel(
                    uid = currentUser.uid,
                    email = currentUser.email ?: "",
                    displayName = currentUser.displayName ?: "Usuario",
                    photoUrl = currentUser.photoUrl?.toString() ?: ""
                )
            } catch (e: Exception) {
                userModel = UserModel(
                    uid = currentUser.uid,
                    email = currentUser.email ?: "",
                    displayName = currentUser.displayName ?: "Usuario",
                    photoUrl = currentUser.photoUrl?.toString() ?: ""
                )
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Column {
                        val avatarModel = remember(userModel?.photoUrl) {
                            getCoilImageModel(
                                selectedUri = null,
                                photoUrl = userModel?.photoUrl,
                                defaultUid = currentUser?.uid ?: "default"
                            )
                        }

                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(avatarModel)
                                .crossfade(true)
                                .decoderFactory(SvgDecoder.Factory())
                                .build(),
                            contentDescription = "Foto de Perfil",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = userModel?.displayName?.ifBlank { "Usuario" } ?: "Usuario",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = userModel?.email?.ifBlank { currentUser?.email ?: "Sin correo" } ?: "Sin correo",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                HorizontalDivider()

                Spacer(modifier = Modifier.height(12.dp))

                NavigationDrawerItem(
                    label = { Text("Configuración") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        onNavigateToSettings()
                    },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Configuración") },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    label = { Text("Guía de Uso / Tutorial") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        tutorialStep = 1
                        showTutorialManually = true
                    },
                    icon = { Icon(Icons.Default.Info, contentDescription = "Tutorial") },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                Spacer(modifier = Modifier.weight(1f))

                HorizontalDivider()

                NavigationDrawerItem(
                    label = { Text("Cerrar Sesión", color = MaterialTheme.colorScheme.error) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        auth.signOut()
                        onSignOut()
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Cerrar Sesión",
                            tint = MaterialTheme.colorScheme.error
                        )
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Eco, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("SHELFLIFE AI", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                Text(
                                    when (currentTab) {
                                        0 -> "Dashboard"
                                        1 -> "Recipes"
                                        2 -> "Scanner AI"
                                        3 -> "Alimentos Frescos"
                                        4 -> "Registro de Pérdidas"
                                        else -> "Dashboard"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Abrir Menú")
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            Toast.makeText(context, "No tienes notificaciones pendientes.", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Default.Notifications, contentDescription = "Notificaciones")
                        }
                        IconButton(onClick = onNavigateToSettings) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Person, contentDescription = "Perfil", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = { Icon(Icons.Default.Kitchen, contentDescription = "Inicio") },
                        label = { Text("Inicio", style = MaterialTheme.typography.labelMedium) }
                    )
                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { currentTab = 1 },
                        icon = { Icon(Icons.Default.RestaurantMenu, contentDescription = "Recetas") },
                        label = { Text("Recetas", style = MaterialTheme.typography.labelMedium) }
                    )
                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = "Escanear", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                                }
                            }
                        },
                        label = { Text("Escanear", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold) }
                    )
                    NavigationBarItem(
                        selected = currentTab == 3,
                        onClick = { currentTab = 3 },
                        icon = { Icon(Icons.Default.Eco, contentDescription = "Frescos") },
                        label = { Text("Frescos", style = MaterialTheme.typography.labelMedium) }
                    )
                    NavigationBarItem(
                        selected = currentTab == 4,
                        onClick = { currentTab = 4 },
                        icon = { Icon(Icons.Default.Spa, contentDescription = "Impacto") },
                        label = { Text("Impacto", style = MaterialTheme.typography.labelMedium) }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    0 -> DashboardTabContent(
                        products = products,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { searchQuery = it },
                        selectedStorageFilter = selectedStorageFilter,
                        onStorageFilterChange = { selectedStorageFilter = it },
                        dateFormatter = dateFormatter,
                        onOpenClick = { product ->
                            val (defaultDays, tip) = getDefaultDaysAndTipForCategory(product.category)
                            openDaysInput = defaultDays.toString()
                            currentTip = tip
                            productToOpen = product
                        },
                        onDeleteClick = { product ->
                            productToDelete = product
                        },
                        shouldShowTutorial = shouldShowTutorial,
                        tutorialStep = tutorialStep
                    )
                    1 -> RecipesTabContent()
                    2 -> ScannerTabContent(
                        onNavigateToAddProduct = onNavigateToAddProduct,
                        productViewModel = productViewModel
                    )
                    3 -> FreshProductsTabContent(
                        products = products,
                        dateFormatter = dateFormatter,
                        onOpenClick = { product ->
                            val (defaultDays, tip) = getDefaultDaysAndTipForCategory(product.category)
                            openDaysInput = defaultDays.toString()
                            currentTip = tip
                            productToOpen = product
                        },
                        onDeleteClick = { product -> productToDelete = product }
                    )
                    4 -> LossRegisterTabContent()
                }

                // Modal Dialog para "Marcar como Abierto"
                productToOpen?.let { selectedProduct ->
                    val nowMillis = System.currentTimeMillis()
                    val daysInt = openDaysInput.toIntOrNull() ?: 3
                    val calculatedOpenedExpiration = nowMillis + (daysInt.toLong() * 24 * 60 * 60 * 1000L)
                    val originalExp = if (selectedProduct.originalExpirationDate > 0) selectedProduct.originalExpirationDate else selectedProduct.expirationDate
                    val finalExp = min(originalExp, calculatedOpenedExpiration)

                    AlertDialog(
                        onDismissRequest = { productToOpen = null },
                        shape = RoundedCornerShape(24.dp),
                        title = { Text("Marcar '${selectedProduct.name}' como Abierto") },
                        text = {
                            Column {
                                Text(
                                    text = "Sugerencia por categoría (${selectedProduct.category}):",
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentTip,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                OutlinedTextField(
                                    value = openDaysInput,
                                    onValueChange = { openDaysInput = it },
                                    label = { Text("Días de duración tras abrir") },
                                    shape = RoundedCornerShape(16.dp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            "Original exp: ${dateFormatter.format(Date(originalExp))}",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(
                                            "Nuevo vencimiento estimado: ${dateFormatter.format(Date(finalExp))}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    productViewModel.markProductAsOpened(selectedProduct, daysInt)
                                    productToOpen = null
                                },
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text("Confirmar")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { productToOpen = null }) {
                                Text("Cancelar")
                            }
                        }
                    )
                }

                // Modal Dialog para Confirmar ELIMINAR PRODUCTO
                productToDelete?.let { selectedProduct ->
                    AlertDialog(
                        onDismissRequest = { productToDelete = null },
                        shape = RoundedCornerShape(24.dp),
                        title = { Text("¿Eliminar producto?") },
                        text = {
                            Text("¿Estás seguro de que deseas eliminar '${selectedProduct.name}'? Esta acción no se puede deshacer.")
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    productViewModel.deleteProduct(selectedProduct.id)
                                    productToDelete = null
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("Eliminar")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { productToDelete = null }) {
                                Text("Cancelar")
                            }
                        }
                    )
                }

                if (shouldShowTutorial && currentTab == 0) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.55f))
                            .padding(16.dp)
                    ) {
                        when (tutorialStep) {
                            1 -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .align(Alignment.TopCenter)
                                        .padding(top = 100.dp),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("1. Barra de Búsqueda", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            "Filtra en tiempo real tus productos almacenados por nombre o categoría.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            Button(
                                                onClick = { tutorialStep = 2 },
                                                shape = RoundedCornerShape(20.dp)
                                            ) {
                                                Text("Siguiente")
                                            }
                                        }
                                    }
                                }
                            }

                            2 -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .align(Alignment.Center)
                                        .padding(horizontal = 8.dp),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("2. Alertas de Vencimiento", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            "Revisa los productos con vencimiento cercano (3 a 5 días) resaltados con colores de alerta.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            OutlinedButton(
                                                onClick = { tutorialStep = 1 },
                                                shape = RoundedCornerShape(20.dp)
                                            ) {
                                                Text("Anterior")
                                            }
                                            Button(
                                                onClick = { tutorialStep = 3 },
                                                shape = RoundedCornerShape(20.dp)
                                            ) {
                                                Text("Siguiente")
                                            }
                                        }
                                    }
                                }
                            }

                            3 -> {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .align(Alignment.BottomEnd)
                                        .padding(bottom = 90.dp),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.AddCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("3. Registrar Productos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            "Presiona el botón '+' para agregar nuevos alimentos manualmente o escaneando con la Cámara IA.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            OutlinedButton(
                                                onClick = { tutorialStep = 2 },
                                                shape = RoundedCornerShape(20.dp)
                                            ) {
                                                Text("Anterior")
                                            }
                                            Button(
                                                onClick = {
                                                    showTutorialManually = false
                                                    scope.launch {
                                                        userPreferences.setTutorialSeen(true)
                                                    }
                                                },
                                                shape = RoundedCornerShape(20.dp)
                                            ) {
                                                Text("¡Entendido!")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 0: DASHBOARD CONTENT (MATCHING IMAGE 1)
// ==========================================
@Composable
fun DashboardTabContent(
    products: List<ProductModel>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedStorageFilter: String,
    onStorageFilterChange: (String) -> Unit,
    dateFormatter: SimpleDateFormat,
    onOpenClick: (ProductModel) -> Unit,
    onDeleteClick: (ProductModel) -> Unit,
    shouldShowTutorial: Boolean,
    tutorialStep: Int
) {
    val nowMillis = System.currentTimeMillis()
    val fiveDaysInMillis = 5 * 24 * 60 * 60 * 1000L

    val filteredProducts = remember(products, searchQuery, selectedStorageFilter) {
        products.filter { product ->
            val matchesQuery = searchQuery.isBlank() ||
                    product.name.contains(searchQuery, ignoreCase = true) ||
                    product.category.contains(searchQuery, ignoreCase = true)

            val matchesFilter = selectedStorageFilter == "Todos" ||
                    product.storageType.equals(selectedStorageFilter, ignoreCase = true)

            matchesQuery && matchesFilter
        }
    }

    val expiringProducts = remember(products) {
        products.filter { product ->
            val diff = product.expirationDate - nowMillis
            diff <= fiveDaysInMillis
        }.sortedBy { it.expirationDate }
    }

    val totalProducts = products.size
    val freshProductsCount = remember(products) {
        products.count { ((it.expirationDate - nowMillis) / (1000 * 60 * 60 * 24)) > 15 }
    }
    val freshPercentage = if (totalProducts > 0) freshProductsCount.toFloat() / totalProducts.toFloat() else 1.0f
    val animatedProgress by animateFloatAsState(
        targetValue = freshPercentage,
        animationSpec = tween(durationMillis = 800),
        label = "FreshAnim"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Header Metrics Card (Exact match to Image 1)
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = Color(0xFFD8E8D9)
                ),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Eco, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${(freshPercentage * 100).toInt()}% frescos", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                            }
                        }

                        if (expiringProducts.isNotEmpty()) {
                            Surface(
                                color = Color(0xFFFFF3E0),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.HourglassTop, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${expiringProducts.size} por vencer en 3 días", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "$totalProducts Alimentos Activos",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B382B)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Excelente rotación. Mantienes el desperdicio al mínimo esta semana.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF385E4D)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = Color(0xFF2E7D32),
                        trackColor = Color.White.copy(alpha = 0.6f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar M3 (Exact match to Image 1)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Buscar en tu despensa o heladera...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                        }
                    }
                },
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (shouldShowTutorial && tutorialStep == 1) {
                            Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(28.dp))
                        } else Modifier
                    ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Storage Filter Chips Row
            val storageOptions = listOf("Todos", "Heladera", "Despensa", "Congelador")
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(storageOptions) { option ->
                    val isSelected = selectedStorageFilter.equals(option, ignoreCase = true) || (option == "Todos" && selectedStorageFilter == "Todos")
                    FilterChip(
                        selected = isSelected,
                        onClick = { onStorageFilterChange(if (option == "Todos") "Todos" else option) },
                        label = { Text(if (option == "Todos") "Todos ($totalProducts)" else option) },
                        shape = RoundedCornerShape(20.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Organizados por vencimiento",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Más urgentes primero ↓",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        if (filteredProducts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Kitchen,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "No hay productos registrados.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }
        } else {
            items(filteredProducts, key = { it.id }) { product ->
                ProductCard(
                    product = product,
                    dateFormatter = dateFormatter,
                    onOpenClick = { onOpenClick(product) },
                    onDeleteClick = { onDeleteClick(product) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))

            // Banner Sugerencia del Chef AI (Image 1 Bottom)
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = Color(0xFFEAF2EC)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFD0E3D3),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(24.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Sugerencia del Chef AI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF1B382B))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("Prepara salteado de pollo con espinacas hoy para aprovechar ingredientes antes de su vencimiento.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF385E4D))
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 1: RECETAS CERO DESPERDICIO (MATCHING IMAGE 4)
// ==========================================
@Composable
fun RecipesTabContent() {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recetas Cero Desperdicio",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = { Toast.makeText(context, "Filtro de recetas", Toast.LENGTH_SHORT).show() }) {
                    Icon(Icons.Default.Tune, contentDescription = "Filtrar")
                }
            }

            Text(
                text = "Basado en 3 ingredientes por vencer en tu heladera",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = {},
                    label = { Text("Pechuga de Pollo • Vence mañana") },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = Color(0xFFFFEBEE),
                        labelColor = Color(0xFFC62828)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                AssistChip(
                    onClick = {},
                    label = { Text("Tomates Cherries") },
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Main Featured Recipe Card
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(Color.LightGray)
                    ) {
                        AsyncImage(
                            model = "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?q=80&w=600",
                            contentDescription = "Receta Principal",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        Surface(
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "Aprovecha 3 productos por vencer",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Surface(
                            color = Color(0xFF2E7D32),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "100% disponible",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Pollo al Horno con Tomates y Espinacas",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Jugoso filete dorado con hierbas frescas, cherries asados y espinacas tiernas.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("25 min", style = MaterialTheme.typography.labelMedium)
                            }
                            Text("•", color = Color.Gray)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Fácil", style = MaterialTheme.typography.labelMedium)
                            }
                            Text("•", color = Color.Gray)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocalFireDepartment, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("420 kcal", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { Toast.makeText(context, "Abriendo receta completa...", Toast.LENGTH_SHORT).show() },
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Ver Pasos de Preparación", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Secondary Recipe 1
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.LightGray)
                    ) {
                        AsyncImage(
                            model = "https://images.unsplash.com/photo-1525351484163-7529414344d8?q=80&w=300",
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Aprovecha 2 por vencer", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Omelette Campestre", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Espinacas salteadas y tomatitos...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = {},
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Ver Pasos >", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Rescue Banner Bottom
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFEBF5EE))
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Recycling, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("¡Excelente rescate culinario! Cocinar cualquiera de estos platos evitará 0.65 kg de CO2e y salvará aprox. $1.85 USD.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF1B382B))
                }
            }
        }
    }
}

// ==========================================
// PREVISUALIZACIÓN DE CÁMARA EN VIVO CON CAMERAX
// ==========================================
@Composable
fun CameraXLivePreview(
    modifier: Modifier = Modifier,
    onImageCaptureCreated: (ImageCapture) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
    val imageCapture = remember { ImageCapture.Builder().build() }

    LaunchedEffect(imageCapture) {
        onImageCaptureCreated(imageCapture)
    }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            try {
                cameraProviderFuture.get().unbindAll()
            } catch (e: Exception) {
                Log.e("CameraX", "Error al desvincular cámara", e)
            }
        }
    }

    AndroidView(
        factory = { ctx ->
            PreviewView(ctx).also { pView ->
                pView.scaleType = PreviewView.ScaleType.FILL_CENTER
                cameraProviderFuture.addListener({
                    try {
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = CameraPreview.Builder().build().also {
                            it.setSurfaceProvider(pView.surfaceProvider)
                        }
                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageCapture
                        )
                    } catch (e: Exception) {
                        Log.e("CameraX", "Error al iniciar previsualización de cámara en vivo", e)
                    }
                }, ContextCompat.getMainExecutor(ctx))
            }
        },
        modifier = modifier
    )
}

@Composable
fun CameraViewfinderOverlay(
    modeTitle: String,
    instructionText: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Marco de Encuadre Central (Retícula profesional)
        Box(
            modifier = Modifier
                .size(240.dp)
                .border(BorderStroke(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.85f)), RoundedCornerShape(24.dp))
                .background(Color.Transparent)
        ) {
            // Esquinas decorativas de enfoque
            Box(modifier = Modifier.size(24.dp).align(Alignment.TopStart).border(BorderStroke(4.dp, Color.White), RoundedCornerShape(topStart = 16.dp)))
            Box(modifier = Modifier.size(24.dp).align(Alignment.TopEnd).border(BorderStroke(4.dp, Color.White), RoundedCornerShape(topEnd = 16.dp)))
            Box(modifier = Modifier.size(24.dp).align(Alignment.BottomStart).border(BorderStroke(4.dp, Color.White), RoundedCornerShape(bottomStart = 16.dp)))
            Box(modifier = Modifier.size(24.dp).align(Alignment.BottomEnd).border(BorderStroke(4.dp, Color.White), RoundedCornerShape(bottomEnd = 16.dp)))
        }

        Surface(
            color = Color.Black.copy(alpha = 0.7f),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 8.dp)
        ) {
            Text(
                text = modeTitle,
                style = MaterialTheme.typography.labelMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        Surface(
            color = Color.Black.copy(alpha = 0.75f),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.CenterFocusStrong, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = instructionText,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

// ==========================================
// TAB 2: ESCANEAR AI (MATCHING IMAGES 3 & 5)
// ==========================================
@androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
@Composable
fun ScannerTabContent(
    onNavigateToAddProduct: () -> Unit,
    productViewModel: ProductViewModel
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isFreshMode by remember { mutableStateOf(true) }
    var selectedStorage by remember { mutableStateOf("Heladera") }

    var activeImageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var capturedBase64 by remember { mutableStateOf("") }
    var detectedName by remember { mutableStateOf("") }
    var detectedCategory by remember { mutableStateOf("Otros") }
    var detectedConfidence by remember { mutableIntStateOf(0) }

    val classifier = remember { ClassifierHolder.get(context) }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
        if (!isGranted) {
            Toast.makeText(context, "Se requiere permiso de cámara para el escáner.", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    fun takeLiveCameraPhoto() {
        val imageCapture = activeImageCapture ?: run {
            Toast.makeText(context, "Iniciando cámara...", Toast.LENGTH_SHORT).show()
            return
        }

        imageCapture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val bitmap = try {
                        image.toBitmap()
                    } catch (e: Exception) {
                        val buffer = image.planes[0].buffer
                        val bytes = ByteArray(buffer.remaining())
                        buffer.get(bytes)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }
                    val mediaImage = image.image
                    val rotationDegrees = image.imageInfo.rotationDegrees
                    image.close()

                    if (bitmap != null) {
                        val outputStream = ByteArrayOutputStream()
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
                        val byteArray = outputStream.toByteArray()
                        capturedBase64 = "data:image/jpeg;base64," + Base64.encodeToString(byteArray, Base64.NO_WRAP)

                        detectedName = ""
                        detectedConfidence = 0

                        if (!isFreshMode && mediaImage != null) {
                            // Modo Empaquetado: Escanear código de barras / QR con ML Kit
                            val mlImage = InputImage.fromMediaImage(mediaImage, rotationDegrees)
                            val scanner = BarcodeScanning.getClient()
                            scanner.process(mlImage)
                                .addOnSuccessListener { barcodes ->
                                    val barcode = barcodes.firstOrNull()?.rawValue
                                    if (!barcode.isNullOrBlank()) {
                                        Toast.makeText(context, "Código detectado: $barcode", Toast.LENGTH_SHORT).show()
                                        coroutineScope.launch {
                                            // Consultar Open Food Facts API
                                            val productInfo = withContext(kotlinx.coroutines.Dispatchers.IO) {
                                                try {
                                                    val url = URL("https://world.openfoodfacts.org/api/v0/product/$barcode.json")
                                                    val conn = url.openConnection() as HttpURLConnection
                                                    conn.requestMethod = "GET"
                                                    conn.connectTimeout = 4000
                                                    if (conn.responseCode == 200) {
                                                        val res = conn.inputStream.bufferedReader().use { it.readText() }
                                                        val json = JSONObject(res)
                                                        if (json.optInt("status", 0) == 1) {
                                                            val prod = json.optJSONObject("product")
                                                            if (prod != null) {
                                                                val name = prod.optString("product_name", prod.optString("product_name_es", "Producto $barcode"))
                                                                val catTag = prod.optJSONArray("categories_tags")?.optString(0) ?: "Abarrotes / Despensa"
                                                                val cat = when {
                                                                    catTag.contains("fruit", true) -> "Frutas"
                                                                    catTag.contains("vegetable", true) -> "Verduras"
                                                                    catTag.contains("dairy", true) -> "Lácteos"
                                                                    catTag.contains("beverage", true) -> "Bebidas"
                                                                    else -> "Abarrotes / Despensa"
                                                                }
                                                                return@withContext Pair(name, cat)
                                                            }
                                                        }
                                                    }
                                                } catch (ex: Exception) {
                                                    Log.e("OpenFoodFacts", "Error", ex)
                                                }
                                                null
                                            }

                                            if (productInfo != null) {
                                                detectedName = productInfo.first
                                                detectedCategory = productInfo.second
                                                detectedConfidence = 95
                                                Toast.makeText(context, "¡Producto encontrado: $detectedName!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                detectedName = "Empaque $barcode"
                                                detectedCategory = "Abarrotes / Despensa"
                                                detectedConfidence = 80
                                                Toast.makeText(context, "Código registrado (sin datos externos)", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    } else {
                                        Toast.makeText(context, "No se detectó código de barras. Usa IA de clasificación.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                .addOnFailureListener {
                                    Toast.makeText(context, "Error al escanear código", Toast.LENGTH_SHORT).show()
                                }
                        } else {
                            // Modo Alimento Fresco: Clasificador YOLOv8
                            if (classifier != null) {
                                val results = runCatching { classifier.classify(bitmap, topK = 3) }.getOrDefault(emptyList())
                                val decision = classifier.decide(results)
                                val best = decision.prediction
                                if (best != null) {
                                    detectedName = best.info.displayName
                                    detectedCategory = best.info.category
                                    detectedConfidence = (best.confidence * 100).toInt()
                                    Toast.makeText(context, "Producto: $detectedName", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "${decision.motivo}. Intenta encuadrar mejor la fruta/verdura.", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("CameraX", "Error al capturar foto", exception)
                    Toast.makeText(context, "Error al capturar foto: ${exception.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Top Segmented Control (Empaquetado vs Alimento Fresco)
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Row(modifier = Modifier.fillMaxSize()) {
                Surface(
                    onClick = {
                        isFreshMode = false
                        detectedName = ""
                        detectedCategory = "Otros"
                    },
                    shape = RoundedCornerShape(24.dp),
                    color = if (!isFreshMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(4.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "Empaquetado",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (!isFreshMode) FontWeight.Bold else FontWeight.Normal,
                            color = if (!isFreshMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    onClick = {
                        isFreshMode = true
                        detectedName = ""
                        detectedCategory = "Otros"
                    },
                    shape = RoundedCornerShape(24.dp),
                    color = if (isFreshMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(4.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Eco, contentDescription = null, modifier = Modifier.size(16.dp), tint = if (isFreshMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Alimento Fresco",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = if (isFreshMode) FontWeight.Bold else FontWeight.Normal,
                                color = if (isFreshMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Camera Viewport Box con Previsualización en Vivo y Overlay de Encuadre
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = Color.Black)
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (hasCameraPermission) {
                    CameraXLivePreview(
                        modifier = Modifier.fillMaxSize(),
                        onImageCaptureCreated = { activeImageCapture = it }
                    )

                    // Overlay de Encuadre Profesional (Retícula para Frutas / Códigos / Fechas)
                    CameraViewfinderOverlay(
                        modeTitle = if (isFreshMode) "Encuadre de Frutas y Verduras" else "Encuadre de Código de Barras / QR",
                        instructionText = if (isFreshMode) "Coloca la fruta dentro del recuadro" else "Alinea el código de barras dentro del marco"
                    )

                    // Disparador de Captura Flotante
                    Surface(
                        onClick = { takeLiveCameraPhoto() },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp)
                            .size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Capturar Foto", tint = Color.White, modifier = Modifier.size(26.dp))
                        }
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(Icons.Default.VideocamOff, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Permiso de cámara requerido para previsualización en vivo", style = MaterialTheme.typography.bodySmall, color = Color.White)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA) }) {
                            Text("Solicitar Permiso")
                        }
                    }
                }

                // Overlay Status Badge Top Left
                Surface(
                    color = Color.Black.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FiberManualRecord, contentDescription = null, tint = Color.Green, modifier = Modifier.size(10.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isFreshMode) "IA Frescos (YOLOv8)" else "Escáner Barcode + Open Food Facts",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bottom Card "Producto Detectado"
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Producto detectado", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Surface(color = Color(0xFFE8F5E9), shape = RoundedCornerShape(12.dp)) {
                        Text("Confianza $detectedConfidence%", style = MaterialTheme.typography.labelMedium, color = Color(0xFF2E7D32), modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(if (isFreshMode) Icons.Default.Eco else Icons.Default.ShoppingBag, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(if (detectedName.isNotBlank()) detectedName else "Ningún producto detectado aún", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(if (detectedName.isNotBlank()) "$detectedCategory • Listo para guardar" else "Apunta la cámara y presiona capturar", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Lugar de conservación recomendado:", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("Heladera", "Despensa", "Congelador").forEach { location ->
                        val isSelected = selectedStorage == location
                        Surface(
                            onClick = { selectedStorage = location },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.weight(1f).height(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    location,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    enabled = detectedName.isNotBlank() && capturedBase64.isNotEmpty(),
                    onClick = {
                        val sevenDaysExp = System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000L)
                        // Usamos addOrUpdateProduct para que si ya existe, sume la cantidad automáticamente
                        productViewModel.addOrUpdateProduct(
                            name = detectedName,
                            category = detectedCategory,
                            quantity = 1.0,
                            unit = "Unidades",
                            storageType = selectedStorage,
                            expirationDate = sevenDaysExp,
                            imageUrl = capturedBase64
                        )
                    },
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirmar y Agregar (Actualiza si ya existe)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(90.dp))
    }
}

// ==========================================
// TAB 3: ALIMENTOS FRESCOS
// ==========================================
@Composable
fun FreshProductsTabContent(
    products: List<ProductModel>,
    dateFormatter: SimpleDateFormat,
    onOpenClick: (ProductModel) -> Unit,
    onDeleteClick: (ProductModel) -> Unit
) {
    val freshList = remember(products) {
        products.filter { it.category in listOf("Frutas", "Verduras", "Lácteos", "Carnes y Embutidos") }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text("Alimentos Frescos (${freshList.size})", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Gestión rápida de vida útil para productos perecederos", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (freshList.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("No hay alimentos frescos perecederos en la lista.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
                }
            }
        } else {
            items(freshList, key = { it.id }) { product ->
                ProductCard(
                    product = product,
                    dateFormatter = dateFormatter,
                    onOpenClick = { onOpenClick(product) },
                    onDeleteClick = { onDeleteClick(product) }
                )
            }
        }
    }
}

// ==========================================
// TAB 4: REGISTRO DE PÉRDIDAS & IMPACTO (MATCHING IMAGE 2)
// ==========================================
@Composable
fun LossRegisterTabContent() {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.EventBusy, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Registro de Pérdidas", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                Surface(color = Color(0xFFE8F5E9), shape = RoundedCornerShape(12.dp)) {
                    Text("Modo Aprendizaje", style = MaterialTheme.typography.labelSmall, color = Color(0xFF2E7D32), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                "Identifica patrones y reduce el desperdicio doméstico con hábitos conscientes.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Time Filter Chips
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = true, onClick = {}, label = { Text("Este Mes (4)") }, shape = RoundedCornerShape(20.dp))
                FilterChip(selected = false, onClick = {}, label = { Text("Últimos 3 Meses") }, shape = RoundedCornerShape(20.dp))
                FilterChip(selected = false, onClick = {}, label = { Text("Histórico Total") }, shape = RoundedCornerShape(20.dp))
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Card Impacto Estimado (Image 2)
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFF5F5))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = Color(0xFFD32F2F))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Impacto Estimado", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
                        }
                        Surface(color = Color(0xFFFFEBEE), shape = RoundedCornerShape(12.dp)) {
                            Text("4 no consumidos", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC62828), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.weight(1f).padding(4.dp)) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Pérdida económica", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text("$18.50 USD", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("+$4.20 vs mes ant.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC62828))
                            }
                        }

                        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.weight(1f).padding(4.dp)) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Huella ambiental", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text("3.2 kg CO2e", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("Evitables con congelado", style = MaterialTheme.typography.labelSmall, color = Color(0xFF2E7D32))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedButton(
                        onClick = { Toast.makeText(context, "Análisis de hábitos...", Toast.LENGTH_SHORT).show() },
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Ver análisis de hábitos de compra ->", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("Artículos para gestionar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            // Discard Item 1
            ElevatedCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(20.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Yogurt Griego Natural 500g", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Lácteos • Heladera", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(color = Color(0xFFFFEBEE), shape = RoundedCornerShape(8.dp)) {
                        Text("Venció hace 3 días (12 Oct) • Olvidado al fondo", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC62828), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = {}, shape = RoundedCornerShape(20.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                        Text("Compostar / Descartar")
                    }
                }
            }

            // Discard Item 2
            ElevatedCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(20.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Espinacas Frescas 200g", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Verduras • Cajón inferior", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(color = Color(0xFFFFEBEE), shape = RoundedCornerShape(8.dp)) {
                        Text("Venció hace 5 días", style = MaterialTheme.typography.labelSmall, color = Color(0xFFC62828), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = {}, shape = RoundedCornerShape(20.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                        Text("Compostar hojas")
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Banner ¿Se puede compostar? (Image 2 Bottom)
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFE8F5E9))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Eco, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("¿Se puede compostar?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF1B382B))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Aprende a clasificar para devolver nutrientes a la tierra y evitar gases nocivos.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF385E4D))

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(shape = RoundedCornerShape(12.dp), color = Color.White, modifier = Modifier.weight(1f).padding(4.dp)) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Compostable", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                                Text("Frutas, verduras, posos de café y cáscaras.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }
                        Surface(shape = RoundedCornerShape(12.dp), color = Color.White, modifier = Modifier.weight(1f).padding(4.dp)) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Descarte común", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                                Text("Pan con moho, carnes, lácteos y procesados.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { Toast.makeText(context, "Todos los ítems marcados como gestionados.", Toast.LENGTH_SHORT).show() },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Marcar todo como gestionado", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// COMPOSABLE COMPONENTE: TARJETA DE PRODUCTO
// ==========================================
@Composable
fun ProductCard(
    product: ProductModel,
    dateFormatter: SimpleDateFormat,
    onOpenClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val context = LocalContext.current
    val nowMillis = System.currentTimeMillis()
    val isOpened = product.isOpened

    val colorTheme = remember(product.expirationDate) {
        getProductStatusColor(product.expirationDate)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = colorTheme.backgroundColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = BorderStroke(1.5.dp, colorTheme.borderColor)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (isOpened) {
                val daysLeft = ((product.expirationDate - nowMillis) / (1000 * 60 * 60 * 24)).toInt()
                val openedMsg = if (daysLeft < 0) "¡Excedió plazo de apertura!" else if (daysLeft == 0) "Consumir HOY mismo" else "Consumir en los próximos $daysLeft días"

                Surface(
                    color = colorTheme.borderColor,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.LockOpen,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "PRODUCTO ABIERTO • $openedMsg",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    if (product.imageUrl.isNotEmpty()) {
                        val avatarModel = getCoilImageModel(
                            selectedUri = null,
                            photoUrl = product.imageUrl,
                            defaultUid = product.id
                        )
                        AsyncImage(
                            model = ImageRequest.Builder(context).data(avatarModel).build(),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = getCategoryIcon(product.category),
                            contentDescription = null,
                            modifier = Modifier.size(32.dp),
                            tint = colorTheme.textColor
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        product.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = colorTheme.textColor
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        "${product.quantity} ${product.unit} - ${product.category}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "Vence: ${dateFormatter.format(Date(product.expirationDate))}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = colorTheme.textColor
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Eliminar Producto",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            product.storageType,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onOpenClick,
                    enabled = !isOpened,
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colorTheme.borderColor,
                        contentColor = Color.White,
                        disabledContainerColor = Color.Gray.copy(alpha = 0.25f),
                        disabledContentColor = Color.Gray
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(38.dp)
                ) {
                    Icon(
                        imageVector = if (isOpened) Icons.Default.Check else Icons.Default.LockOpen,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isOpened) "Envase Abierto" else "Abrir Envase",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
