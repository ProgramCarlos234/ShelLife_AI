package com.example.shelflife_ai.ui.product

import android.util.Base64
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.shelflife_ai.model.ProductModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.min

sealed class ProductUiState {
    object Idle : ProductUiState()
    object Loading : ProductUiState()
    data class Success(val message: String) : ProductUiState()
    data class Error(val message: String) : ProductUiState()
}

class ProductViewModel : ViewModel() {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()

    /** Única colección de productos: /products, filtrada por userId. */
    private val productsCollection get() = firestore.collection("products")

    private val _products = MutableStateFlow<List<ProductModel>>(emptyList())
    val products: StateFlow<List<ProductModel>> = _products.asStateFlow()

    private val _uiState = MutableStateFlow<ProductUiState>(ProductUiState.Idle)
    val uiState: StateFlow<ProductUiState> = _uiState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private var snapshotListener: ListenerRegistration? = null

    // Guardamos el listener para poder quitarlo en onCleared (antes se filtraba).
    private val authListener = FirebaseAuth.AuthStateListener { loadProducts() }

    init {
        auth.addAuthStateListener(authListener)
        loadProducts()
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun resetUiState() {
        _uiState.value = ProductUiState.Idle
    }

    fun loadProducts() {
        val currentUser = auth.currentUser
        snapshotListener?.remove()

        if (currentUser == null) {
            _products.value = emptyList()
            return
        }

        snapshotListener = productsCollection
            .whereEqualTo("userId", currentUser.uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("ProductError", "Error de lectura en Firestore: ${error.code}", error)
                    _uiState.value = ProductUiState.Error(
                        if (error.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
                            "Permisos insuficientes para cargar los productos."
                        else
                            "Error al cargar productos: ${error.localizedMessage}"
                    )
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(ProductModel::class.java)?.copy(id = doc.id)
                    }
                    _products.value = list.sortedBy { it.expirationDate }
                }
            }
    }

    fun addProduct(
        name: String,
        category: String,
        quantity: Double,
        unit: String,
        storageType: String,
        expirationDate: Long,
        imageUrl: String
    ) {
        addOrUpdateProduct(name, category, quantity, unit, storageType, expirationDate, imageUrl)
    }

    /**
     * Agrega un producto o lo actualiza automáticamente si ya existe en el inventario
     * del usuario (suma la cantidad y ajusta la fecha si corresponde).
     */
    fun addOrUpdateProduct(
        name: String,
        category: String,
        quantity: Double,
        unit: String,
        storageType: String,
        expirationDate: Long,
        imageUrl: String
    ) {
        val currentUser = auth.currentUser ?: run {
            _uiState.value = ProductUiState.Error("Debes iniciar sesión para agregar productos.")
            return
        }
        if (name.isBlank()) {
            _uiState.value = ProductUiState.Error("El nombre del producto es obligatorio.")
            return
        }

        viewModelScope.launch {
            _uiState.value = ProductUiState.Loading
            try {
                val normalizedName = name.trim().lowercase()
                val existingProduct = _products.value.firstOrNull {
                    it.userId == currentUser.uid && it.name.trim().lowercase() == normalizedName
                }

                if (existingProduct != null && existingProduct.id.isNotBlank()) {
                    // El producto ya existe: incrementamos la cantidad y actualizamos
                    val newQuantity = existingProduct.quantity + quantity
                    val updates = mapOf(
                        "quantity" to newQuantity,
                        "storageType" to storageType,
                        "expirationDate" to if (expirationDate > 0 && expirationDate < existingProduct.expirationDate) expirationDate else existingProduct.expirationDate
                    )
                    productsCollection.document(existingProduct.id).update(updates).await()
                    _uiState.value = ProductUiState.Success("¡Producto existente actualizado! Se sumaron $quantity $unit (Total: $newQuantity).")
                } else {
                    // Producto nuevo
                    val docRef = productsCollection.document()
                    val finalImageUrl = uploadImageIfNeeded(currentUser.uid, docRef.id, imageUrl)

                    val newProduct = ProductModel(
                        id = docRef.id,
                        userId = currentUser.uid,
                        name = name.trim(),
                        category = category,
                        quantity = quantity,
                        unit = unit,
                        expirationDate = expirationDate,
                        originalExpirationDate = expirationDate,
                        storageType = storageType,
                        imageUrl = finalImageUrl,
                        isOpened = false,
                        createdAt = System.currentTimeMillis()
                    )
                    docRef.set(newProduct).await()
                    _uiState.value = ProductUiState.Success("Producto registrado correctamente.")
                }
            } catch (e: FirebaseFirestoreException) {
                Log.e("ProductError", "Error de Firestore al guardar: Code ${e.code}", e)
                _uiState.value = ProductUiState.Error(
                    if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
                        "Permisos insuficientes en Firestore. Verifica que hayas iniciado sesión correctamente."
                    else
                        "Error en la base de datos: ${e.localizedMessage}"
                )
            } catch (e: Exception) {
                Log.e("ProductError", "Error al agregar producto", e)
                _uiState.value = ProductUiState.Error(e.localizedMessage ?: "Error al registrar producto.")
            }
        }
    }

    /** Si la imagen es base64 (data:image...), la sube a Storage y devuelve su URL pública. */
    private suspend fun uploadImageIfNeeded(uid: String, productId: String, imageData: String): String {
        if (!imageData.startsWith("data:image")) return imageData
        val bytes = Base64.decode(imageData.substringAfter("base64,"), Base64.DEFAULT)
        val ref = storage.reference.child("products/$uid/$productId.jpg")
        ref.putBytes(bytes).await()
        return ref.downloadUrl.await().toString()
    }

    fun markProductAsOpened(product: ProductModel, openedDays: Int) {
        if (product.id.isBlank()) return

        viewModelScope.launch {
            _uiState.value = ProductUiState.Loading
            try {
                val now = System.currentTimeMillis()
                val openedExpiration = now + (openedDays.toLong() * 24 * 60 * 60 * 1000L)
                val originalExp = if (product.originalExpirationDate > 0) product.originalExpirationDate else product.expirationDate
                val finalExpirationDate = min(originalExp, openedExpiration)

                val updates = mapOf(
                    "isOpened" to true,
                    "openedDate" to now,
                    "openedDaysLimit" to openedDays,
                    "originalExpirationDate" to originalExp,
                    "expirationDate" to finalExpirationDate
                )
                productsCollection.document(product.id).update(updates).await()
                _uiState.value = ProductUiState.Success("Producto marcado como abierto. Vencimiento recalculado.")
            } catch (e: FirebaseFirestoreException) {
                Log.e("ProductError", "Error de Firestore al actualizar: Code ${e.code}", e)
                _uiState.value = ProductUiState.Error(
                    if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
                        "Permisos insuficientes para modificar el producto."
                    else
                        "Error de actualización: ${e.localizedMessage}"
                )
            } catch (e: Exception) {
                _uiState.value = ProductUiState.Error(e.localizedMessage ?: "Error al recalcular vencimiento.")
            }
        }
    }

    fun deleteProduct(productId: String) {
        if (productId.isBlank()) return
        val uid = auth.currentUser?.uid ?: return

        viewModelScope.launch {
            _uiState.value = ProductUiState.Loading
            try {
                productsCollection.document(productId).delete().await()
                // Limpieza best-effort de la foto; si no existe no es un error.
                runCatching { storage.reference.child("products/$uid/$productId.jpg").delete().await() }
                _uiState.value = ProductUiState.Success("Producto eliminado correctamente.")
            } catch (e: FirebaseFirestoreException) {
                Log.e("ProductError", "Error de Firestore al eliminar: Code ${e.code}", e)
                _uiState.value = ProductUiState.Error(
                    if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
                        "Permisos insuficientes para eliminar el producto."
                    else
                        "Error al eliminar: ${e.localizedMessage}"
                )
            } catch (e: Exception) {
                _uiState.value = ProductUiState.Error(e.localizedMessage ?: "Error al eliminar producto.")
            }
        }
    }

    override fun onCleared() {
        auth.removeAuthStateListener(authListener)
        snapshotListener?.remove()
        super.onCleared()
    }
}
