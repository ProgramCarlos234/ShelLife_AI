package com.example.shelflife_ai.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Palette (#3B6748)
val PrimaryGreen = Color(0xFF3B6748)
val OnPrimaryGreen = Color(0xFFFFFFFF)
val PrimaryGreenContainer = Color(0xFFBCEECA)
val OnPrimaryGreenContainer = Color(0xFF00210E)

val SecondaryGreen = Color(0xFF526353)
val SecondaryGreenContainer = Color(0xFFD5E8D4)
val OnSecondaryGreenContainer = Color(0xFF101F12)

val TertiaryTeal = Color(0xFF39656B)
val TertiaryTealContainer = Color(0xFFBCEBF1)
val OnTertiaryTealContainer = Color(0xFF001F23)

// Neutral & Surface
val LightBackground = Color(0xFFF6FBF4)
val LightOnBackground = Color(0xFF181D18)
val LightSurface = Color(0xFFF6FBF4)
val LightOnSurface = Color(0xFF181D18)
val LightSurfaceVariant = Color(0xFFDEE5DA)
val LightOnSurfaceVariant = Color(0xFF424940)
val LightOutline = Color(0xFF72796F)

// Dark Palette
val DarkBackground = Color(0xFF101411)
val DarkOnBackground = Color(0xFFE0E4DE)
val DarkSurface = Color(0xFF101411)
val DarkOnSurface = Color(0xFFE0E4DE)
val DarkSurfaceVariant = Color(0xFF424940)
val DarkOnSurfaceVariant = Color(0xFFC2C9BD)
val DarkOutline = Color(0xFF8C9388)

// Expiration Status Color Tokens
val FreshGreen = Color(0xFF2E7D32)
val FreshGreenContainer = Color(0xFFE8F5E9)
val FreshGreenBorder = Color(0xFF81C784)

val WarningOrange = Color(0xFFEF6C00)
val WarningOrangeContainer = Color(0xFFFFF8E1)
val WarningOrangeBorder = Color(0xFFFFB74D)

val ExpiredRed = Color(0xFFC62828)
val ExpiredRedContainer = Color(0xFFFFEBEE)
val ExpiredRedBorder = Color(0xFFE57373)
