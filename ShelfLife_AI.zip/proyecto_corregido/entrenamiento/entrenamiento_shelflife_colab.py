# ==========================================================================
# ShelLife - Entrenamiento YOLOv8-cls para Google Colab
# Cada bloque "# %%" es una celda. Pégalas en orden en Colab.
# Todo se guarda en Google Drive: si Colab se desconecta, retoma donde quedó.
# ==========================================================================

# %% 1. Dependencias y Google Drive
# !pip -q install ultralytics kagglehub
# from google.colab import drive
# drive.mount('/content/drive')

# %% 2. Configuración
import shutil, random, hashlib
from pathlib import Path
from collections import defaultdict

RUN_NAME = 'v1'                                   # cambia a v2, v3... en cada entrenamiento
DRIVE_DIR = Path('/content/drive/MyDrive/shelflife')
RUNS_DIR = DRIVE_DIR / 'runs'
EXPORT_DIR = DRIVE_DIR / 'export'                 # aquí aparecen best.tflite y labels.txt
REAL_TEST = DRIVE_DIR / 'real_test'               # TUS fotos con el celular: NUNCA se entrenan
NEGATIVE_DIR = DRIVE_DIR / 'no_alimento'          # fotos de objetos que NO son comida
DATASET = Path('/content/dataset')                # dataset temporal (se reconstruye en cada corrida)

IMG_EXT = {'.jpg', '.jpeg', '.png', '.webp', '.bmp'}
SPLIT_WORDS = {'train', 'test', 'val', 'valid', 'validation', 'images', 'labels', 'input'}
ALIASES = {'capsicum': 'bell_pepper', 'sweetcorn': 'corn'}   # mismas verduras, una sola clase
MIN_IMAGES = 30
random.seed(42)

# %% 3. Descargar datasets de alimentos (verifica los slugs en kaggle.com si alguno falla)
import kagglehub
FOOD_SOURCES = [
    kagglehub.dataset_download("kritikseth/fruit-and-vegetable-image-recognition"),
    kagglehub.dataset_download("vinayakshanawad/meat-freshness-image-dataset"),
    # kagglehub.dataset_download("moltean/fruits"),   # Fruits-360: descomenta para más variedad
]

# %% 4. Construir /content/dataset (train/val) con clase no_alimento
def class_of(path, root):
    """Nombre de la carpeta más cercana que no sea un nombre de split."""
    for part in reversed(Path(path).relative_to(root).parts[:-1]):
        name = part.lower().replace(' ', '_').replace('-', '_')
        if name not in SPLIT_WORDS:
            return ALIASES.get(name, name)
    return None

def collect(sources, negative=False):
    items = defaultdict(list)
    for root in sources:
        for p in Path(root).rglob('*'):
            if p.suffix.lower() not in IMG_EXT:
                continue
            cls = 'no_alimento' if negative else class_of(p, root)
            if cls:
                items[cls].append(p)
    return items

all_items = defaultdict(list)
for src, neg in [(FOOD_SOURCES, False), ([str(NEGATIVE_DIR)], True)]:
    for cls, paths in collect(src, negative=neg).items():
        all_items[cls].extend(paths)

# Quitar duplicados exactos (el mismo archivo en varias fuentes)
def md5(p):
    return hashlib.md5(Path(p).read_bytes()).hexdigest()

for cls in list(all_items):
    seen, unique = set(), []
    for p in all_items[cls]:
        h = md5(p)
        if h not in seen:
            seen.add(h)
            unique.append(p)
    all_items[cls] = unique

# Revisa esta tabla ANTES de entrenar
print(f"{'clase':22s} imágenes")
for cls in sorted(all_items):
    aviso = '   <- muy pocas, se omite' if len(all_items[cls]) < MIN_IMAGES else ''
    print(f"{cls:22s} {len(all_items[cls]):>8}{aviso}")

if not any(c.startswith('carne') for c in all_items):
    print("⚠ No aparecen clases de carne: revisa la estructura del dataset de carnes.")
if 'no_alimento' not in all_items:
    print("⚠ Falta no_alimento: agrega fotos a", NEGATIVE_DIR, "o el rechazo no funcionará.")

if DATASET.exists():
    shutil.rmtree(DATASET)
for cls, paths in all_items.items():
    if len(paths) < MIN_IMAGES:
        continue
    random.shuffle(paths)
    split = int(len(paths) * 0.8)
    for subset, lista in [('train', paths[:split]), ('val', paths[split:])]:
        dest = DATASET / subset / cls
        dest.mkdir(parents=True, exist_ok=True)
        for i, p in enumerate(lista):
            shutil.copy(p, dest / f"{i:06d}{p.suffix.lower()}")
print("Dataset listo en", DATASET)

# %% 5. Entrenar (si Colab se corta, vuelve a ejecutar esta celda: retoma desde last.pt)
from ultralytics import YOLO

last = RUNS_DIR / RUN_NAME / 'weights' / 'last.pt'
if last.exists():
    print("Retomando entrenamiento desde", last)
    model = YOLO(str(last))
    model.train(resume=True)
else:
    model = YOLO('yolov8s-cls.pt')
    model.train(
        data=str(DATASET),
        epochs=100,
        patience=20,                 # se detiene si ya no mejora
        imgsz=224,
        batch=32,
        lr0=0.001,
        dropout=0.2,
        degrees=15.0,
        scale=0.5,
        fliplr=0.5,
        hsv_h=0.015, hsv_s=0.7, hsv_v=0.4,
        erasing=0.4,
        auto_augment='randaugment',
        project=str(RUNS_DIR), name=RUN_NAME, exist_ok=True,
        save_period=5,               # guarda un checkpoint cada 5 épocas en Drive
    )

# %% 6. Evaluar con TUS fotos reales (las que nunca se usaron para entrenar)
best_pt = RUNS_DIR / RUN_NAME / 'weights' / 'best.pt'
model = YOLO(str(best_pt))

ok = total = 0
fallos = []
for clase_dir in sorted(REAL_TEST.iterdir()):
    if not clase_dir.is_dir():
        continue
    for img in clase_dir.glob('*'):
        if img.suffix.lower() not in IMG_EXT:
            continue
        r = model.predict(str(img), verbose=False)[0]
        pred, conf = r.names[r.probs.top1], float(r.probs.top1conf)
        total += 1
        if pred == clase_dir.name and conf >= 0.75:
            ok += 1
        else:
            fallos.append((clase_dir.name, pred, round(conf, 2)))

if total:
    print(f"Aciertos con fotos reales (con umbral 0.75): {ok}/{total} = {ok/total:.1%}")
    print("Errores más comunes (real -> predicho, confianza):")
    for real, pred, conf in fallos[:20]:
        print(f"  {real} -> {pred} ({conf})")
else:
    print("⚠ Carpeta real_test vacía: agrega fotos tuyas para medir la precisión real.")

# %% 7. Exportar a TFLite y generar labels.txt en el MISMO orden del modelo
EXPORT_DIR.mkdir(parents=True, exist_ok=True)

names = [model.names[i] for i in range(len(model.names))]
(EXPORT_DIR / 'labels.txt').write_text('\n'.join(names) + '\n', encoding='utf-8')
print("labels.txt generado con", len(names), "clases")

model.export(format='tflite', imgsz=224, half=False)
tflite_files = list((RUNS_DIR / RUN_NAME / 'weights').rglob('*float32.tflite'))
if tflite_files:
    shutil.copy(tflite_files[0], EXPORT_DIR / 'best.tflite')
    print("best.tflite copiado a", EXPORT_DIR)
else:
    print("⚠ No se encontró el .tflite; revisa la carpeta weights.")

# Después: descarga EXPORT_DIR desde Drive y copia:
#   best.tflite  -> app/src/main/assets/best.tflite
#   labels.txt   -> app/src/main/assets/labels.txt
